function hideShorts() {
  // پیدا کردن تمام المان‌هایی که ممکنه Shorts باشن
  const shortsElements = document.querySelectorAll(
    'a[href*="/shorts/"], ' + // لینک‌های Shorts
      "ytd-reel-shelf-renderer, " + // قفسه Shorts تو صفحه اصلی
      "ytd-rich-item-renderer, " + // آیتم‌های Shorts تو Subscriptions یا نتایج
      "ytd-grid-video-renderer, " + // ویدیوهای گرید تو صفحه اصلی
      'ytd-thumbnail[href*="/shorts/"], ' + // پیش‌نمایش‌های Shorts
      "[is-shorts]" // المان‌هایی با ویژگی is-shorts
  );

  shortsElements.forEach((element) => {
    // چک کردن اینکه آیا واقعاً Shorts هست
    if (
      element.querySelector('a[href*="/shorts/"]') || // داره لینک Shorts
      element.tagName === "YTD-REEL-SHELF-RENDERER" || // قفسه Shorts
      element.querySelector("[is-shorts]") || // ویژگی Shorts
      element.innerText.toLowerCase().includes("#shorts") // تگ #shorts
    ) {
      element.style.display = "none"; // مخفی کردن
    }
  });

  // اگه تو صفحه پخش Shorts باشه، ریدایرکت به صفحه اصلی
  if (window.location.pathname.startsWith("/shorts/")) {
    window.location.href = "https://www.youtube.com/";
  }
}

// اجرای اولیه تابع
hideShorts();

// مشاهده تغییرات داینامیک صفحه
const observer = new MutationObserver(() => {
  hideShorts();
});
observer.observe(document.body, { childList: true, subtree: true });
