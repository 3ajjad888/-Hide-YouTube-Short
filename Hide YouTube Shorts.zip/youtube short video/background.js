chrome.runtime.onInstalled.addListener(() => {
  console.log("YouTube Shorts Blocker installed.");
});